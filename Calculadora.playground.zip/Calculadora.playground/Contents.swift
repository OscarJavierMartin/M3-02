import UIKit

var primerNumero : Float = 0.0
var operacion : String = "s"
var segundoNumero : Float = 0.0
var resultado : Float = 0.0

print("Escribe el primer número: ")
primerNumero = Float(readLine()!)!

print("""
    Tipo de operación:
    s -> Suma
    r -> Resta
    m -> Multiplicación
    d -> División
    """)
operacion = readLine()!

print("Escribe el segundo número: ")
segundoNumero = Float(readLine()!)!

switch operacion {
case "s", "S", "suma", "Suma":
    
    print("El resultado es : \(suma(num1 : primerNumero, num2 : segundoNumero))")
case "r", "R", "resta", "Resta" :
    print("El resultado es : \(resta(num1 : primerNumero, num2 : segundoNumero))")
case "m", "M", "multiplicacion", "Multiplicacion":
    print("El resultado es : \(producto(num1 : primerNumero, num2 : segundoNumero))")
case "d", "D", "Division", "division":
    print("El resultado es : \(division(num1 : primerNumero, num2 : segundoNumero))")
default:
    print("Operación desconocida")
}


func suma(num1 : Float, num2 : Float){
    var resultado = num1 + num2
}
func resta(num1 : Float, num2 : Float){
    var resultado = num1 - num2
}

func producto(num1 : Float, num2 : Float){
    var resultado = num1 * num2
}

func division(num1 : Float, num2 : Float){
    if (num2 == 0){
        print("No se puede dividir entre cero")
    }else{
        var resultado = num1 / num2
    }
}
/*
print("Ingrese el primer número:")
let numero1 = Float(readLine()!)!

print("Ingrese el segundo número:")
let numero2 = Float(readLine()!)!

print("Elija la operación que desea realizar (+, -, *, /):")
let operacion = readLine()!

var resultado: Float = 0.0

switch operacion {
case "+":
    resultado = numero1 + numero2
case "-":
    resultado = numero1 - numero2
case "*":
    resultado = numero1 * numero2
case "/":
    resultado = numero1 / numero2
default:
    print("Operación inválida")
}

print("El resultado de la operación \(operacion) es: \(resultado)")
*/

